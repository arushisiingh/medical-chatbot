from setuptools import find_packages, setup

setup(
    name = 'Generative AI Project',
    version= '0.0.0',
    author= 'Bappy Ahmed',
    author_email= 'entbappy73@gmail.com',
    packages= find_packages(),
    install_requires = []

)